<head>
 </head>
 <?php include 'links.php'; ?>
<?php  include 'includes/header.php'; ?>

	
	<!-- popup -->

	<div>
		
button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>


<!-- Page Title -->
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>Our Media</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
					<!-- Blog Post Excerpt -->
					<div class="col-sm-6">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<h2><span style="color: #aec62c ; text-transform: uppercase;font-size: 50px">Lamborghini</span></h2>
							</div>

							<div class="single-post-image">
								<img src="img/blog/la2.jpg" alt="Post Title">
							</div>
							
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i>15 OCT, 2017 <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
							</div>
							
							<div class="single-post-content">
								<p>
									Automobili Lamborghini S.p.A. is an Italian brand and manufacturer of luxury supercars, sports cars and SUVs based in Sant'Agata Bolognese, Italy. The company is owned by the Volkswagen Group through its subsidiary Audi.
								</p>
							<a href="blog-post.html" class="btn">Read more</a>
							</div>
						</div>
					</div>
					<!-- End Blog Post Excerpt -->
					

					<!-- Blog Post Excerpt -->
					<div class="col-sm-6">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<h2><span style="color: #aec62c ; text-transform: uppercase;font-size: 50px">bmw</span></h2>
							</div>

							<div class="single-post-image">
								<img src="img/blog/b1.jpg" alt="Post Title">
							</div>
							
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i>15 OCT, 2017 <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
							</div>
							
							<div class="single-post-content">
								<p>
									Bayerische Motoren Werke AG, usually known under its abbreviation BMW, is a German luxury vehicle, motorcycle, and engine manufacturing company founded in 1916. It is one of the best-selling luxury automakers in the world.
								</p>
							<a href="blog-post.html" class="btn">Read more</a>
							</div>
						</div>
					</div>
					<!-- End Blog Post Excerpt -->

					<!-- Blog Post Excerpt -->
					<div class="col-sm-6">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<h2><span style="color: #aec62c ; text-transform: uppercase;font-size: 50px"> Range Rover</h2>
							</div>

							<div class="single-post-image">
								<img src="img/blog/r1.jpg" alt="Post Title">
							</div>
							
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i>15 OCT, 2014 <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
							</div>
							
							<div class="single-post-content">
								<p>
									The Range Rover is a British made, full-sized luxury sport utility vehicle produced by Land Rover, and serves as its flagship model. Land Rover is one of several auto manufacturers owned by Tata Motors, a part of the Indian multinational conglomerate Tata Group. The Range Rover was launched in 1970. It is now in its fourth generation. Land Rover has expanded the Range Rover model line to include different designs: the Range Rover Evoque, the Range Rover Velar and the Range Rover Sport.
								</p>
							<a href="blog-post.html" class="btn">Read more</a>
							</div>
						</div>
					</div>
					<!-- End Blog Post Excerpt -->

					<!-- Blog Post Excerpt -->
					<div class="col-sm-6">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<h2><span style="color: #aec62c ; text-transform: uppercase;font-size: 50px">maserati</h2>
							</div>

							<div class="single-post-image">
								<img src="img/blog/m1.jpg" alt="Post Title">
							</div>
							
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i>15 OCT, 2014 <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
							</div>
							
							<div class="single-post-content">
								<p>
									Maserati is an Italian luxury vehicle manufacturer established on 1 December 1914, in Bologna. The Maserati tagline is "Luxury, sports and style cast in exclusive cars", and the brand's mission statement is to "Build ultra-luxury performance automobiles with timeless Italian style, accommodating bespoke interiors, and effortless, signature sounding power".
								</p>
							<a href="blog-post.html" class="btn">Read more</a>
							</div>
						</div>
					</div>
					<!-- End Blog Post Excerpt -->	

										

				</div>
			</div>
	    </div>
	    <!-- End Our Clients -->

	   	  	    <?php include 'includes/footer.php'; ?>


        <!-- Javascripts -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
		
		<!-- Scrolling Nav JavaScript -->
		<script src="js/jquery.easing.min.js"></script>
		<script src="js/scrolling-nav.js"></script>		

    </body>
</html>